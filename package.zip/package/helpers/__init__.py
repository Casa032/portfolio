from helpers.generation_structure import generer_structure, ResultatGeneration

__all__ = [
    "generer_structure",
    "ResultatGeneration",
]
